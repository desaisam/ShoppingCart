import React, { useState, useEffect } from "react";
import "./ProductList.css";
import Card from "react-bootstrap/Card";
import { Button } from "react-bootstrap";

export default function ProductList(props) {
  //   console.log(`Props in Products List ${JSON.stringify(props)}`);
  const [products, setProducts] = useState(props.products);
  //   console.log(`Product State in Prod List : ${JSON.stringify(products)}`);

  const [sortType, setSortType] = useState("None");

  const [filterType, setFilterType] = useState("0");

  const handleClick = (clickedName, clickedPrice, clickedItemId) => {
    // setResult(result => [...result, response]);
    props.setCartItem((item) => [
      ...props.cartItem,
      {
        name: clickedName,
        price: clickedPrice,
        id: clickedItemId,
      },
    ]);
  };

  useEffect(() => {
    // console.log(`Copy of Products ${copy}`);
    const sortArray = (type) => {
      //   console.log(`Sorting by ${type}`);
      if (type === "price") {
        const sorted = [...products].sort((a, b) => b.price - a.price);
        setProducts(sorted);
      }

      if (type === "name") {
        const sorted = [...products].sort((a, b) =>
          //   console.log(`${a.name.toUpperCase()} ${b.name.toUpperCase()}`)
          {
            if (a.name.toUpperCase() < b.name.toUpperCase()) {
              return -1;
            }

            if (a.name.toUpperCase() > b.name.toUpperCase()) {
              return 1;
            }
          }
        );
        // console.log(`Sorted Array ${JSON.stringify(sorted)}`);
        setProducts(sorted);
      }
      if (type === "None") {
        const sorted = [...products].sort((a, b) => -(b.id - a.id));
        setProducts(sorted);
      }
    };

    const fillterArray = (type) => {
      console.log(`Filtering by ${type}`);

      if (type === "Appliance") {
        const filterd = [...props.products].filter((a) => a.category === type);
        setProducts(filterd);
      }
      if (type === "Games") {
        const filterd = [...props.products].filter((a) => a.category === type);
        setProducts(filterd);
      }
      if (type === "Health and Beauty") {
        const filterd = [...props.products].filter((a) => a.category === type);
        setProducts(filterd);
      }
      if (type === "None") {
        setProducts(props.products);
      }
    };
    sortArray(sortType);
    fillterArray(filterType);
  }, [sortType, filterType]);

  return (
    <div className="ProductList">
      <h2>Products</h2>
      <div className="ProductList-filter">
        <label htmlFor="sort">Sort By</label>
        <select onChange={(e) => setSortType(e.target.value)}>
          <option default>None</option>
          <option value="name">Name</option>
          <option value="price">Price</option>
        </select>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <label htmlFor="filter">Filter by Category</label>
        <select
          name="filter"
          id="sort"
          onChange={(e) => setFilterType(e.target.value)}
        >
          <option default>None</option>
          <option value="Appliance">Appliance</option>
          <option value="Games">Games</option>
          <option value="Health and Beauty">Health and Beauty</option>
        </select>
      </div>
      {products.map((prod) => {
        return (
          <Card key={prod.id} className="ProductList-product">
            <Card.Body>
              <Card.Title>
                {prod.name} - ${prod.price}
              </Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                {prod.category}
              </Card.Subtitle>
              <Card.Text>{prod.description}</Card.Text>
              {/* <Card.Link href="#">Add To Cart</Card.Link> */}
              <Button
                onClick={() => handleClick(prod.name, prod.price, prod.id)}
              >
                Add To Cart
              </Button>
            </Card.Body>
          </Card>
        );
      })}
      <br />
      <br />
    </div>
  );
}
