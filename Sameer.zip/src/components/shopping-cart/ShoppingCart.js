import "./ShoppingCart.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import React, { useState, useEffect } from "react";

// Note from the team:
//   Right now this is hard-coded with example data.
//   It needs to be converted to show the real items in the shopping cart!
export default function ShoppingCart(props) {
  console.log(`Props in Shopping ${JSON.stringify(props)}`);
  console.log(`ID : ${props.cartItem.id}`);
  const [qty, setQty] = useState(0);
  const [price, setPrice] = useState(props.cartItem.price);
  useEffect(() => {
    setPrice(props.cartItem.price);
    if (props.cartItem.id !== "") {
      setQty(1);
    }
  }, [props.cartItem]);
  //   setPrice(props.cartItem.price);
  const decreasQty = () => {
    if (qty === 0) {
      return;
    } else {
      setQty(qty - 1);
    }
  };

  const increaseQty = () => {
    setQty(qty + 1);
  };
  return (
    <div className="ShoppingCart">
      <h2>
        Shopping Cart <FontAwesomeIcon icon={faShoppingCart} />
      </h2>
      <div className="ShoppingCart-contents">
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Qty</th>
              <th>Price</th>
            </tr>
            {props.cartItem.map((listValue, index) => {
              console.log(listValue.name);
              return (
                <tr key={index}>
                  <td>
                    {listValue.name} ${listValue.price}
                  </td>
                  <td>
                    <button onClick={decreasQty}>-</button>
                    <input
                      type="number"
                      value={qty}
                      onChange={(e) => setQty(e.target.value)}
                    />
                    <button onClick={increaseQty}>+</button>
                  </td>
                  <td>{qty * listValue.price}</td>
                </tr>
              );
            })}
          </thead>
          <tbody>
            <tr>
              <td colSpan="2"></td>
              <td>Total: {qty * price}</td>
            </tr>
            <tr>
              <td colSpan="3">
                <label htmlFor="coupon">Coupon</label>
                <input id="coupon" type="text" defaultValue="" />
                <button>Apply</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
